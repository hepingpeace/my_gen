---
name: General questions
about: Ask general questions to get help
title: ''
labels: ''
assignees: ''
---

**Checklist**

1. I have searched related issues but cannot get the expected help.
2. I have read the FAQ documentation but cannot get the expected help.
