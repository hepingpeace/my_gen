#ifndef TRT_PLUGIN_HPP
#define TRT_PLUGIN_HPP

extern "C" {
bool initLibMMCVInferPlugins();
}  // extern "C"
#endif  // TRT_PLUGIN_HPP
